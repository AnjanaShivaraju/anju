package com.Refill.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Refill.Main.RefillMain;
import com.Refill.Service.RefillService;


@RequestMapping("/Refill")
@RestController
@CrossOrigin
public class RefillController {
	@Autowired
	private RefillService service;
	
	

	@GetMapping("/refill")
	public List<RefillMain> getall(){
		return service.getall();
	}
	
	@PostMapping("/add")
	public RefillMain add(@RequestBody RefillMain refillmain) {
		return service.add(refillmain);
	}
	
	
	
	

}
