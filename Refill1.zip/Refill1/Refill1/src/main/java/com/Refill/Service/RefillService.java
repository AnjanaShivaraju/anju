package com.Refill.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Refill.Main.RefillMain;
import com.Refill.Repository.RefillRepository;


@Service
public class RefillService {
	
	@Autowired 
	private RefillRepository prepost;
	
	public List<RefillMain> getall()
	{
		return prepost.findAll();
		
	}
	public RefillMain add(RefillMain refillmain) {
		return prepost.save(refillmain);
	}
	
	
}
