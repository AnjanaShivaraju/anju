package com.Refill.Main;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class RefillMain {

@Id
	private int subscriptionid;
	private String name;
	private Date refilldate ;

	private int refillorderid;

	private int refillquantity;

	private String refillstatus;

	public int getSubscriptionid() {
		return subscriptionid;
	}

	public void setSubscriptionid(int subscriptionid) {
		this.subscriptionid = subscriptionid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getRefilldate() {
		return refilldate;
	}

	public void setRefilldate(Date refilldate) {
		this.refilldate = refilldate;
	}

	public int getRefillorderid() {
		return refillorderid;
	}

	public void setRefillorderid(int refillorderid) {
		this.refillorderid = refillorderid;
	}

	public int getRefillquantity() {
		return refillquantity;
	}

	public void setRefillquantity(int refillquantity) {
		this.refillquantity = refillquantity;
	}

	public String getRefillstatus() {
		return refillstatus;
	}

	public void setRefillstatus(String refillstatus) {
		this.refillstatus = refillstatus;
	}

	public RefillMain(int subscriptionid, String name, Date refilldate, int refillorderid, int refillquantity,
			String refillstatus) {
		super();
		this.subscriptionid = subscriptionid;
		this.name = name;
		this.refilldate = refilldate;
		this.refillorderid = refillorderid;
		this.refillquantity = refillquantity;
		this.refillstatus = refillstatus;
	}

	public RefillMain() {
		super();
		// TODO Auto-generated constructor stub
	}

}