package com.example.mailorderpharmacy;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class MailOrderPharmacyApplication {
	
    @GetMapping("/find")
    public List<product> getBooks(){
    	return Stream.of(new product(101,"java",999),
    			new product(104,"Angular",888)).collect(Collectors.toList());
    }
	public static void main(String[] args) {
		SpringApplication.run(MailOrderPharmacyApplication.class, args);
		System.out.println("Finish");
	}

}
