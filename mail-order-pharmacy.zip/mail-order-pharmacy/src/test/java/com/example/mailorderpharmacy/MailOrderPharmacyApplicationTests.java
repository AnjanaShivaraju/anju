package com.example.mailorderpharmacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailOrderPharmacyApplicationTests {

	@Test
	void contextLoads() {
	}

}
