package com.drug.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drug.Main.DrugMain;
import com.drug.Repository.DrugRepository;

@Service
public class DrugService {
	
	@Autowired 
	private DrugRepository prepost;
	
	public List<DrugMain> getall()
	{
		return prepost.findAll();
		
	}

	public List<DrugMain> getid() {
		// TODO Auto-generated method stub
		return prepost.findAll();
	}
	
}
