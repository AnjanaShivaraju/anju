package com.drug.Repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.drug.Main.DrugMain;

public interface DrugRepository  extends JpaRepository<DrugMain,Integer>{



	
	

}
