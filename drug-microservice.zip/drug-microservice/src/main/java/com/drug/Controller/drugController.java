package com.drug.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drug.Main.DrugMain;
import com.drug.Service.DrugService;

@RequestMapping("/drug")
@RestController
@CrossOrigin
public class drugController {
	@Autowired
	private DrugService service;
	
	
	@GetMapping("/getdrugname")
	public List<DrugMain> getall(){
		return service.getall();
	}
	
	@GetMapping("/getdrugid")
	public List<DrugMain> getid(){
		return service.getid();
	}
	 
	

}
