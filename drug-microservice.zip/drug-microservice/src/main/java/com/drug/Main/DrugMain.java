package com.drug.Main;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class DrugMain {

	@Id
	private int drugid;
	private String drugname; 
	private Date expirydate;
	private Date manufacturedate; 
	private String manufacturer;
	private String location;
	private String quantity;
	private String image;
	public DrugMain(String image) {
		super();
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getDrugid() {
		return drugid;
	}
	public void setDrugid(int drugid) {
		this.drugid = drugid;
	}
	public String getDrugname() {
		return drugname;
	}
	public void setDrugname(String drugname) {
		this.drugname = drugname;
	}
	public Date getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(Date expirydate) {
		this.expirydate = expirydate;
	}
	public Date getManufacturedate() {
		return manufacturedate;
	}
	public void setManufacturedate(Date manufacturedate) {
		this.manufacturedate = manufacturedate;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public DrugMain(int drugid, String drugname, Date expirydate, Date manufacturedate, String manufacturer,
			String location, String quantity) {
		super();
		this.drugid = drugid;
		this.drugname = drugname;
		this.expirydate = expirydate;
		this.manufacturedate = manufacturedate;
		this.manufacturer = manufacturer;
		this.location = location;
		this.quantity = quantity;
	}
	public DrugMain() {
		super();
		// TODO Auto-generated constructor stub
	}
}
	