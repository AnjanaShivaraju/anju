import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DrugsComponent } from './drugs/drugs.component';
import { LoginComponent} from './login/login.component';
import { MailOrderComponent } from './mail-order/mail-order.component';
import { RefillComponent } from './refill/refill.component';
import { RegisterComponent } from './register/register.component';
import { SubscribeComponent } from './subscribe/subscribe.component';





const routes: Routes = [
  {path:"drugs", component:DrugsComponent},
  {path:"refill", component:RefillComponent},
  {path:"subscribe", component:SubscribeComponent},
  {path:'', component:LoginComponent},
  {path:'signup', component:RegisterComponent},
  {path:'mail-order', component:MailOrderComponent}
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
