import { Component } from '@angular/core';
import { DrugsService } from '../drugs.service';
import { Drugs } from '../Models/drugs';
import { SharingService } from '../sharing.service';

@Component({
  selector: 'app-drugs',
  templateUrl: './drugs.component.html',
  styleUrls: ['./drugs.component.css']
})
export class DrugsComponent {

  searchTerm:string='';

  drugs:Drugs[]=[];

  constructor(private drugService:DrugsService,private sharing:SharingService){}

  ngOnInit(): void{
    this.getDrugs();
  }

  getDrugs(){
    this.drugService.getDrugs().subscribe({
    next:(res) => { this.drugs=res

    },
    
    })
    this.sharing.search.next(this.searchTerm)
  }
  
  search(event: any) {
     this.searchTerm = (event.target as HTMLInputElement).value;
     // console.log(this.searchTerm);
     this.sharing.search.next(this.searchTerm)
  }
  getDrugslocation(){
    this.drugService.getDrugslocation().subscribe({
    next:(res) => { this.drugs=res

    },
    
    })
    this.sharing.search.next(this.searchTerm)
  }
  ngOnInitn() {
    document.body.className = "selector";
  }
  
}