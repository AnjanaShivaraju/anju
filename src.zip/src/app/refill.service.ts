import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Refill } from './Models/refill';

@Injectable({
  providedIn: 'root'
})
export class RefillService {
 
  private url: string ="http://localhost:8766/Refill/getrefillduesdate";
  private rurl: string ="http://localhost:8766/Refill/add"
  constructor(private http:HttpClient) { }
  getrefill(){
    return this.http.get<Refill[]>(this.url)
   }
   createRefill(fill:Refill)
   {
    return this.http.post(`${this.rurl}`,fill);
  }

  
  
}
