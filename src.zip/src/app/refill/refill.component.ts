import { Component, OnInit } from '@angular/core';
import { Refill } from '../Models/refill';
import { RefillService } from '../refill.service';

@Component({
  selector: 'app-refill',
  templateUrl: './refill.component.html',
  styleUrls: ['./refill.component.css']
})
export class RefillComponent implements OnInit{
  errorMessage: String="";
  panelOpenState = false;
  refill:Refill[]=[];
  fill:Refill = new Refill();
  constructor(private refillService:RefillService){}

  ngOnInit(): void{
    this.getrefill();
  }
  getrefill(){
    this.refillService.getrefill().subscribe({
      next:(res) => { this.refill=res

    },
    
    })
    
  }
  createfill()
  {
    this.refillService.createRefill(this.fill).subscribe({
      next:(data)=>
      {
        console.log(data);
      },
      error:(e)=>
      {
        console.log(e);
      }
    });
  }

  onSubmit()
  {
    console.log(this.fill);
    this.createfill();
    alert('Refill Added Sucessfully');
  
  }
 
}
