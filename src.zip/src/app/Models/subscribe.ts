export class Subscribe{
    subscriptionid:number;
    drugname:string;
    doctorname : string;
    refillOccurence: string;
    insurencePolicyNumber: number;
    prescriptiondate:number;
    insurenceProvider: string;
}