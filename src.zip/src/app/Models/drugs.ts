export class Drugs{
    drugid: number;
    drugname: string;
    expirydate: Date;
    manufacturedate:Date;
    manufacturer:string;
    location:string;
    quantity: number;
    image: string;
}