export class Refill{
    subscriptionid: number;
    name: string;
    refilldate: Date;
    refillorderid: number;
    refillquantity: number;
    refillstatus: string;
}