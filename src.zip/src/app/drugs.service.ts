import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Drugs } from './Models/drugs';

@Injectable({
  providedIn: 'root'
})
export class DrugsService {
  
  private url: string ="http://localhost:1089/drug/getdrugname";
  private url1: string ="http://localhost:1089/drug/getdrugid"
  constructor(private http:HttpClient) { }
  getDrugs(){
    return this.http.get<Drugs[]>(this.url)
   }
   getDrugslocation(){
    return this.http.get<Drugs[]>(this.url1)
   }


}
