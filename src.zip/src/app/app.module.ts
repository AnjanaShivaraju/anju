import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { MatCard } from "@angular/material/card";
import { MatProgressBar, MatProgressBarModule } from "@angular/material/progress-bar";
import {MatPaginatorModule} from '@angular/material/paginator';
import { MatCalendar } from "@angular/material/datepicker";
import {MatBadgeModule} from '@angular/material/badge';
import { MatMenuModule } from "@angular/material/menu";
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from "@angular/material/icon";
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import {MatTableModule} from '@angular/material/table';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { DrugsComponent } from './drugs/drugs.component';
import { RefillComponent } from './refill/refill.component';

import { TopbarComponent } from './topbar/topbar.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SubscribeComponent } from './subscribe/subscribe.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ReactiveFormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { MailOrderComponent } from './mail-order/mail-order.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DrugsComponent,
    RefillComponent,
    
    TopbarComponent,
         SubscribeComponent,
         RegisterComponent,
         MailOrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCardModule,
    MatExpansionModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatFormFieldModule,
    MatTableModule,
    FormsModule,
    MatToolbarModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
