import { Component, OnInit } from '@angular/core';
import { Subscribe } from '../Models/subscribe';
import { SubscribeService } from '../subscribe.service';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit{
errorMessage: String="";
  panelOpenState = false;
  subscribe:Subscribe[]=[];
  subs:Subscribe = new Subscribe();
  constructor(private subscribeService:SubscribeService){}

  ngOnInit(): void{
    this.getsubscribe();
  }
  getsubscribe(){
    this.subscribeService.getsubscribe().subscribe({
      next:(res) => { this.subscribe=res

    },
    
    })
    
  }
  addSubscribe()
  {
    this.subscribeService.createSubscribe(this.subs).subscribe({
      next:(data)=>
      {
        console.log(data);
      },
      error:(e)=>
      {
        console.log(e);
      }
    });
  }

  onSubmit()
  {
    console.log(this.subs);
    this.addSubscribe();
    alert('Subscription Added Sucessfully');
  }

  delete(id:number)
  {
    this.subscribeService.deleteSubscribe(id).subscribe(data=>{
      console.log(data);
      this.getsubscribe();
      alert("deleted");
    });
  }
 
}
