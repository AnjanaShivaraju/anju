import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscribe } from './Models/subscribe';
import { map } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SubscribeService {
 
  private url: string ="http://localhost:8765/Subscription/subscription";
  private urlsub: string ="http://localhost:8765/Subscription/add";
  private delsub: string ="http://localhost:8765/Subscription/subscription";
  constructor(private http:HttpClient) { }
  getsubscribe(){
    return this.http.get<Subscribe[]>(this.url)
   }

   createSubscribe(subscribe:Subscribe)
   {
    return this.http.post(`${this.urlsub}`,subscribe);
  }
   deleteSubscribe(id:number) {
     return this.http.delete(`${this.delsub}/${id}`);
  
}
}

