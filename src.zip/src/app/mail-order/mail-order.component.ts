import { Component } from '@angular/core';

@Component({
  selector: 'app-mail-order',
  templateUrl: './mail-order.component.html',
  styleUrls: ['./mail-order.component.css']
})
export class MailOrderComponent {
  ngOnInit(): void {
  }
}
