package com.Subscription.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Subscription.Main.SubscriptionMain;


public interface SubscriptionRepository  extends JpaRepository<SubscriptionMain,Integer>
{
}