package com.Subscription.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Subscription.Main.SubscriptionMain;
import com.Subscription.Repository.SubscriptionRepository;


@Service
public class SubscriptionService {
	
	@Autowired 
	private SubscriptionRepository prepost;
	
	public List<SubscriptionMain> getall()
	{
		return prepost.findAll();
		
	}
	public SubscriptionMain add(SubscriptionMain subscriptionmain) {
		return prepost.save(subscriptionmain);
	}
	
	public void unsubscribe(int subscriptionid) {
		
		prepost.deleteById(subscriptionid);
		
	}
	

}
