package com.Subscription.Main;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class SubscriptionMain{
	
	@Id
	private int subscriptionid;
	private Long InsurencePolicyNumber;
	private String InsurenceProvider;
	private Date Prescriptiondate;
	private String drugname; 
	private String doctorname;
	private String refillOccurence;
	public int getSubscriptionid() {
		return subscriptionid;
	}
	public void setSubscriptionid(int subscriptionid) {
		this.subscriptionid = subscriptionid;
	}
	public Long getInsurencePolicyNumber() {
		return InsurencePolicyNumber;
	}
	public void setInsurencePolicyNumber(Long insurencePolicyNumber) {
		InsurencePolicyNumber = insurencePolicyNumber;
	}
	public String getInsurenceProvider() {
		return InsurenceProvider;
	}
	public void setInsurenceProvider(String insurenceProvider) {
		InsurenceProvider = insurenceProvider;
	}
	public Date getPrescriptiondate() {
		return Prescriptiondate;
	}
	public void setPrescriptiondate(Date prescriptiondate) {
		Prescriptiondate = prescriptiondate;
	}
	public String getDrugname() {
		return drugname;
	}
	public void setDrugname(String drugname) {
		this.drugname = drugname;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getRefillOccurence() {
		return refillOccurence;
	}
	public void setRefillOccurence(String refillOccurence) {
		this.refillOccurence = refillOccurence;
	}
	public SubscriptionMain(int subscriptionid, Long insurencePolicyNumber, String insurenceProvider,
			Date prescriptiondate, String drugname, String doctorname, String refillOccurence) {
		super();
		this.subscriptionid = subscriptionid;
		InsurencePolicyNumber = insurencePolicyNumber;
		InsurenceProvider = insurenceProvider;
		Prescriptiondate = prescriptiondate;
		this.drugname = drugname;
		this.doctorname = doctorname;
		this.refillOccurence = refillOccurence;
	}
	public SubscriptionMain() {
		super();
		// TODO Auto-generated constructor stub
	}

}
